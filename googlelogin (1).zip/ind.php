<html>
    <head>
    <title></title>
    </head>
    <body>
        <form action="upload3.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit" name="submit"></button>
        </form>
    </body>
</html>